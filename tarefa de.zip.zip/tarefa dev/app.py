from flask import Flask, render_template, request, redirect, url_for, session

app = Flask(__name__)
app.secret_key = 'secreto123'  # Chave para manter a sessão do usuário

# Código secreto para login
CODIGO_SECRETO = "27111719"

# Lista de tarefas
tarefas = []


# Página de Login (Somente com código secreto)
@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        codigo = request.form['codigo']

        if codigo == CODIGO_SECRETO:
            session['autenticado'] = True  # Autenticar usuário
            return redirect(url_for('home'))
        else:
            return render_template('login.html', erro="Código incorreto!")

    return render_template('login.html')


# Página Home (Somente se estiver autenticado)
@app.route('/home')
def home():
    if not session.get('autenticado'):
        return redirect(url_for('login'))

    return render_template('home.html', tarefas=tarefas)


# Página de Adicionar Tarefa
@app.route('/add', methods=['GET', 'POST'])
def add():
    if not session.get('autenticado'):
        return redirect(url_for('login'))

    if request.method == 'POST':
        materia = request.form['materia']
        pagina = request.form['pagina']
        data = request.form['data']

        nova_tarefa = {"materia": materia, "pagina": pagina, "data": data}
        tarefas.append(nova_tarefa)

        return redirect(url_for('home'))

    return render_template('add.html')


# Excluir tarefa
@app.route('/delete/<int:index>')
def delete(index):
    if not session.get('autenticado'):
        return redirect(url_for('login'))

    if 0 <= index < len(tarefas):
        del tarefas[index]
    return redirect(url_for('home'))


# Logout
@app.route('/logout')
def logout():
    session.pop('autenticado', None)
    return redirect(url_for('login'))


if __name__ == '__main__':
    app.run(debug=True)



